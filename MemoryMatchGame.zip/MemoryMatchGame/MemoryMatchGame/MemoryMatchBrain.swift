//
//  MemoryMatchBrain.swift
//  MemoryMatchGame
//
//  Created by user178070 on 11/4/20.
//

import Foundation

struct Node{
    var emoji = ""
    var matched = false
}
var str = "Hello, playground"
class MemoryMatchBrain
{
    
    
    var emojiArr : [String] = ["😃", "😸", "🐶", "🐼", "😳", "🧶", "👑", "👶", "🎅", "🐳"]
    
    var emojiCount : [Int] = Array(repeating: 2, count: 10)
    var node : Node
    var boardArr = [[Node]]()
    
    init() {
        node = Node()
    
    }
    
    func initializeArr()
    {
        var count = 0
        print("func called")
        for r in 0..<4
        {
            var row = [Node]()
            for elem in 0..<5{
                count+=1
                var emojiFound = false
                
                while(emojiFound == false)
                {
                    var randEmoji = Int.random(in: 0...9)
                    
                    if emojiCount[randEmoji] > 0
                    {
                        emojiFound = true
                        emojiCount[randEmoji] -= 1
                        print("rand emoji number:", randEmoji , " Emoji inserted: " , emojiArr[randEmoji] )
                        var newNode = Node()
                        newNode.emoji = emojiArr[randEmoji]
                        row.append(newNode)
                        
                    }
                    
                }
            }
            boardArr.append(row)
        }
        print ("Finished filling nodes: ", count)
        for col1 in boardArr
        {
            for nod1 in col1
            {
                print(nod1)
            }
        }
        print(boardArr)
        
    }
    
    func getRowCol(tag : Int)->(Int, Int)
    {
        var row = 0
        var col = 0
        col =  tag % 4
        
        switch tag {
        case 0...3:
            row = 0
        case 4...7:
            row = 1
        case 8...11:
            row = 2
        case 12...15:
            row = 3
        case 16...19:
            row = 4
            
        default:
            row = 0
        
        }
        return (row, col)
    }
    /*
    func getEmoji(tag : Int)->String
    {
        var count = 0
        for col in boardArr
        {
            for elem in col
            {
                if count == tag
                {
                    return elem.emoji
                }
                else
                {
                    count+=1
                }
            }
        }
        return "error"
    }
 */
    func getEmoji(tag : Int)->String
    {
        var (row, col) = getRowCol(tag: tag)
        
        var emojiNode = boardArr[col][row]
        return emojiNode.emoji
    }
    
    func isMatch(tag1: Int, tag2 : Int)->(Bool)
    {
        var (row1, col1) = getRowCol(tag: tag1)
        var (row2, col2) = getRowCol(tag: tag2)
        
        var emojiNode1 = boardArr[col1][row1]
        var emojiNode2 = boardArr[col2][row2]
        
        if emojiNode1.emoji == emojiNode2.emoji
        {
            emojiNode1.matched = true
            emojiNode2.matched = true
            boardArr[col1][row1] = emojiNode1
            boardArr[col2][row2] = emojiNode2
            print(emojiNode1.emoji + " == " + emojiNode2.emoji)
            print(emojiNode1.matched , " == " , emojiNode2.matched)
            
            return true
        }
        
        return false //else
    }
    
    func checkBoard()->Bool
    {
        
        var count = 0
        for col in boardArr
        {
            for elem in col
            {
            
                if elem.matched == false
                {
                    print("not all matched yet")
                    print(elem.emoji + " Not matched")
                    print(elem)
                    return false
                }
                count += 1
            }
        }
        print("all matched")
        return true
    }
}

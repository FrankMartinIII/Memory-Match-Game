//
//  ViewController.swift
//  MemoryMatchGame
//
//  Created by user178070 on 10/29/20.
//

import UIKit
var board = MemoryMatchBrain()
var cards = Array(repeating: false, count: 20)
var prevFlippedCards : [Int] = [Int]()
var buttons : [UIButton] = [UIButton]()
var matched : [UIButton] = [UIButton]()
var pressed : [UIButton] = [UIButton]()
var movesMade = 0
var movesLeft = 40

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        board.initializeArr()
    }

    @IBOutlet weak var lblMovesMade: UILabel!
    
    @IBOutlet weak var lblMovesLeft: UILabel!
    @IBOutlet weak var lblVictory: UILabel!
    
    
    @IBAction func btnClick(_ sender: UIButton) {
        var newLabel: String?
        var image: UIImage = UIImage()
        
        /*
        if let label = sender.titleLabel?.text
        {
            print(label)
            newLabel = label
        }
        else
        {
            print("label was nil")
            newLabel = " "
        }
        
        if newLabel != " "
        {
            print("button already flipped and has text")

        }
        
        else
        {
            print("flipping button")
            image = UIImage()
            newLabel = board.getEmoji(tag: sender.tag)
            cards[sender.tag] = true
            buttons.append(sender)
            prevFlippedCards.append(sender.tag)
            cardsFlipped += 1
        }
        
        sender.setTitle(newLabel, for: .normal)
        
        sender.setBackgroundImage(image, for: .normal)

        
        if cardsFlipped > 1
        {
            image = (UIImage(named: "hardwood-tree-400x266.png") as UIImage?)!
            newLabel = " "
            var counter = 0
            for c in prevFlippedCards
            {
                cards[c] = false
                
                buttons[counter].setTitle(newLabel, for: .normal)
                buttons[counter].setBackgroundImage(image, for: .normal)
                
            }
            prevFlippedCards.removeAll()
            buttons.removeAll()
            cardsFlipped = 0
        }
        
        
        */
        
        if !buttons.contains(sender) && !matched.contains(sender)
        {
            //if card not flipped
            flip(sender: sender)
            buttons.append(sender)
            pressed.append(sender)
        }
        
        if buttons.count == 2
        {
            //check for match
            if board.isMatch(tag1: buttons[0].tag, tag2: buttons[1].tag)
            {
                print("match found")
                matched.append(buttons[0])
                matched.append(buttons[1])
                buttons.remove(at: 0)
                buttons.remove(at: 0)
                if board.checkBoard()
                {
                    print("Victory text")
                    //self.view.bringSubviewToFront(lblVictory)
                    //lblVictory.layer.zPosition = 1
                    //lblVictory.isUserInteractionEnabled = true
                    //lblVictory.text = "You Win!"
                    //lblVictory.superview!.bringSubviewToFront(lblVictory)
                    
                    let myAlert = UIAlertController(title: "Victory!", message: "Press OK to play again", preferredStyle: UIAlertController.Style.alert)
                                    
                    myAlert.addAction(UIAlertAction(title:"OK", style: UIAlertAction.Style.default, handler: {reset in
                        
                        self.resetGame()
                    }))
                                    
                    self.present(myAlert, animated:true, completion: nil)
                                    

                    
                }
                movesMade+=1
                movesLeft-=1
                
            }
            //increment moves
            
        }
        
        else if buttons.count > 2
        {
            for b in 0..<buttons.count-1
            {
                unflip(sender: buttons[b])
            }
            buttons.removeFirst()
            buttons.removeFirst()
            movesMade+=1
            movesLeft-=1
        }
        
        if movesLeft <= 0
        {
            let myAlert = UIAlertController(title: "You Lose", message: "Press OK to play again", preferredStyle: UIAlertController.Style.alert)
                            
            myAlert.addAction(UIAlertAction(title:"OK", style: UIAlertAction.Style.default, handler: {reset in
                
                self.resetGame()
            }))
                            
            self.present(myAlert, animated:true, completion: nil)
        }
        
        lblMovesMade.text = String(movesMade)
        lblMovesLeft.text = String(movesLeft)
    }
    
    func flip(sender : UIButton)
    {
        
        print("flipping button")
        var image = UIImage()
        var newLabel = board.getEmoji(tag: sender.tag)
        
        
        sender.setTitle(newLabel, for: .normal)
        sender.setBackgroundImage(image, for: .normal)
        
    }
    
    func unflip(sender : UIButton)
    {
        print("unflipping button")
        var image = (UIImage(named: "hardwood-tree-400x266.png") as UIImage?)!
        var newLabel = " "
        sender.setTitle(newLabel, for: .normal)
        sender.setBackgroundImage(image, for: .normal)
    }
    
    /*
    func getAllButtonFromView()  {
    
        for insideView in view.subviews {
            if insideView.subviews.count > 0 {
                getAllButtonFromView(view: insideView)
            }
            else if (insideView.isKind(of: UIButton.self)) {
                buttons.append(insideView as! UIButton)
            }
        }
     
        for t in 0...19
        {
            guard var b = self.view.viewWithTag(t) as? UIButton else { return  }
     
            buttons.append(b)
        }
    }
    
    */
 
    func resetGame()
    {
        for b in pressed
        {
            print("unflipping " , b.tag)
            self.unflip(sender: b)
        }
        buttons.removeAll()
        matched.removeAll()
        pressed.removeAll()
        board = MemoryMatchBrain()
        board.initializeArr()
        movesMade = 0
        movesLeft = 40
        self.lblMovesMade.text = String(movesMade)
        self.lblMovesLeft.text = String(movesLeft)
        
    }
    
}


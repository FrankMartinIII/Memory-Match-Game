import UIKit
struct Node{
    var emoji = ""
    var matched = false
}
var str = "Hello, playground"
class MemoryMatchBrain
{
    
    
    var emojiArr : [String] = ["😃", "😸", "🐶", "🐼", "😳", "🧶", "👑", "👶", "🎅", "🐳"]
    
    var emojiCount : [Int] = Array(repeating: 2, count: 10)
    var node : Node
    var boardArr = [[Node]]()
    
    init() {
        node = Node()
    
    }
    
    func initializeArr()
    {
        var count = 0
        print("func called")
        for r in 0..<4
        {
            var row = [Node]()
            for elem in 0..<5{
                count+=1
                var emojiFound = false
                
                while(emojiFound == false)
                {
                    var randEmoji = Int.random(in: 0...9)
                    
                    if emojiCount[randEmoji] > 0
                    {
                        emojiFound = true
                        emojiCount[randEmoji] -= 1
                        print("rand emoji number:", randEmoji , " Emoji inserted: " , emojiArr[randEmoji] )
                        var newNode = Node()
                        newNode.emoji = emojiArr[randEmoji]
                        row.append(newNode)
                        
                    }
                    
                }
            }
            boardArr.append(row)
        }
        print ("Finished filling nodes: ", count)
        for col1 in boardArr
        {
            for nod1 in col1
            {
                print(nod1)
            }
        }
        print(boardArr)
        
    }
    
}

var brain = MemoryMatchBrain()
brain.initializeArr()


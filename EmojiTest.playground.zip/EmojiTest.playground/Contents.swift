import UIKit
struct Node{
    var emoji = ""
    var matched = false
}
var str = "Hello, playground"
print(str)
class MemoryMatchBrain
{
    
    
    var emojiArr : [String] = ["😃", "😸", "🐶", "🐼", "😳", "🧶", "👑", "👶", "🎅", "🐳"]
    
    var emojiCount : [Int] = Array(repeating: 2, count: 10)
    var node : Node
    var boardArr : [[Node]]
    
    init() {
        node = Node()
        boardArr = [[Node]](repeating: [Node](repeating: Node(), count: 4), count: 5)
    }
    
    func initializeArr()
    {
        var count = 0
        print("func called")
        for var col in boardArr
        {
            for var nod in col{
                count+=1
                var emojiFound = false
                print(type(of: nod))
                while(emojiFound == false)
                {
                    var randEmoji = Int.random(in: 0...9)
                    
                    if emojiCount[randEmoji] > 0
                    {
                        emojiFound = true
                        emojiCount[randEmoji] -= 1
                        print("rand emoji number:", randEmoji , " Emoji inserted: " , emojiArr[randEmoji] )
                        //nod.emoji = emojiArr[randEmoji]
                        var newNode : Node = Node()
                        newNode.emoji = emojiArr[randEmoji]
                        nod = newNode
                        print(nod.emoji)
                        print(nod)
                                            }
                    
                }
            }
        }
        print ("Finished filling nodes: ", count)
        for col1 in boardArr
        {
            for nod1 in col1
            {
                print(nod1)
            }
        }
        print(boardArr)
        
    }
    
}
print(3)
var brain = MemoryMatchBrain()
brain.initializeArr()
print("hi")
